   
from landerFuncs import *

def main():
   showWelcome()
   alt = getAltitude()
   fuel = getFuel()
   print("\nLM state at retrorocket cutoff")

   count = 0
   vel = 0
   displayLMState(count, alt, 0, fuel, 0)

   
   while(alt > 0):
      count += 1
      rate = getFuelRate(fuel)
      fuel -= rate
      ex = updateAcceleration(1.62, rate)
      vel = updateVelocity(vel, ex)
      alt = updateAltitude(alt, vel, ex)
      if (alt < 0):
         alt = 0
      else:
         displayLMState(count, alt, rate, fuel, vel)
         print('')


   print("\nLM state at landing/impact") 
   displayLMState(count, alt, rate, fuel, vel)
   print("")
   displayLMLandingStatus(vel)



if __name__ == '__main__':
   main()
   